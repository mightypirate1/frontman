import { TextField } from "@mui/material";
import { useState } from "react";

async function getSomeStuff(text: string) {
  const url = `https://www.google.se/search?q=${encodeURIComponent(text)}`;

  const result = await fetch(url);

  console.log(result);
}

function App() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<string>("");

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100vw",
        height: "100vh",
        flexDirection: "column",
      }}
    >
      <div>Hej, vad är din fråga?</div>
      <div>
        <TextField
          variant="outlined"
          placeholder="Ask me anything!"
          onKeyDown={async (e) => {
            if (e.key === "Enter") {
              setResult(e.target.value);
            }
          }}
        />
      </div>
      {result ? <App /> : null}
      <button onClick={() => setText("JALLA JALLA!!!")}>
        Hej klom och hdjsad
      </button>
    </div>
  );
}

export default App;
